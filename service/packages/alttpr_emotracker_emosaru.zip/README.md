# Official EmoTracker ALTTPR Pack Source

This package source is provided for use as reference by all **EmoTracker** pack developers. I do not provide any support for working with this source beyond discussions in the [**EmoTracker Discord**](https://discord.gg/aPHDBZk), and I do not accept merge requests.

Enjoy.
